import tkinter as tk
from tkinter import Label, filedialog, Text
from PIL import Image, ImageTk

# Constants
BLOCK_SIZE = 50
INITIAL_BLOCKS = 25
BLOCKS_INCREMENT = 25
BLOCK_TYPE = "Green"

def change_block(BT):
    global BLOCK_TYPE
    BLOCK_TYPE = BT

def move_rect(event):
    global BLOCKS
    key = event.keysym
    if key == "a":
        move_player(-0.5, 0)
    elif key == "d":
        move_player(0.5, 0)
    elif key == "w":
        move_player(0, -0.5)
    elif key == "s":
        move_player(0, 0.5)
    elif key == "b":
        place_block()
    elif key == "m":
        mine_block()
    # Update the label text
    label.config(text=f"Use WASD to move around. Press 'b' to place a block and 'm' to mine. Blocks: {BLOCKS}")

def move_player(dx, dy):
    # Move the player by block size
    canvas.move(player_sprite, dx * BLOCK_SIZE, dy * BLOCK_SIZE)

def place_block():
    global BLOCKS
    if BLOCKS > 0:
        x, y = canvas.coords(player_sprite)
        canvas.create_rectangle(x, y, x + BLOCK_SIZE, y + BLOCK_SIZE, fill=BLOCK_TYPE)
        BLOCKS -= 1
        canvas.itemconfig(player_sprite, fill=BLOCK_TYPE)  # Update the player sprite color

def mine_block():
    global BLOCKS
    x, y = canvas.coords(player_sprite)
    items = canvas.find_overlapping(x, y, x + BLOCK_SIZE, y + BLOCK_SIZE)
    for item in items:
        if item != player_sprite:
            canvas.delete(item)
            BLOCKS += 1

def add_blocks():
    global BLOCKS
    BLOCKS += BLOCKS_INCREMENT
    label.config(text=f"Use WASD to move around. Press 'b' to place a block and 'm' to mine. Blocks: {BLOCKS}")
    root.after(120000, add_blocks)  # Schedule the function to run again after 2 minutes (120,000 milliseconds)

def save_to_file():
    filename = filedialog.asksaveasfilename(defaultextension=".mbg", filetypes=[("MBG Files", "*.mbg")])
    if filename:
        try:
            with open(filename, "w") as file:
                for item in canvas.find_all():
                    if item != player_sprite:
                        x1, y1, x2, y2 = canvas.coords(item)
                        block_type = canvas.itemcget(item, "fill")
                        file.write(f"{x1},{y1},{x2},{y2},{block_type}\n")
            print(f"Saved to {filename}")
        except Exception as e:
            print(f"Error saving: {e}")

def open_from_file():
    filename = filedialog.askopenfilename(filetypes=[("MBG Files", "*.mbg")])
    if filename:
        # Read block data from the file and recreate blocks on the canvas
        saved_blocks = []  # Store block data
        with open(filename, "r") as file:
            for line in file:
                x1, y1, x2, y2, block_type = line.strip().split(",")
                saved_blocks.append((float(x1), float(y1), float(x2), float(y2), block_type))

        # Clear existing blocks (except the player sprite)
        for item in canvas.find_all():
            if item != player_sprite:
                canvas.delete(item)

        # Recreate saved blocks
        for x1, y1, x2, y2, block_type in saved_blocks:
            canvas.create_rectangle(x1, y1, x2, y2, fill=block_type)

def Clear_Canvas():
    for item in canvas.find_all():
        if item != player_sprite:
            canvas.delete(item)

def toggle_fullscreen(event):
    root.attributes('-fullscreen', not root.attributes('-fullscreen'))




# Initialize
BLOCKS = INITIAL_BLOCKS

root = tk.Tk()
root.title("Minecraft-Like Sprite")
root.geometry("1550x950")
root.iconbitmap("Python.ico")

label = Label(text=f"Use WASD to move around. Press 'b' to place a block and 'm' to mine. Blocks: {BLOCKS}")
label.pack()

canvas = tk.Canvas(root, bg="Sky blue", height=900, width=1550)
canvas.pack()

# Load your PNG image (replace 'Sprite.png' with the actual filename)
image = Image.open("Sprite.png")
photo = ImageTk.PhotoImage(image)

# Display the image on the canvas
player_sprite = canvas.create_image(0, 0, image=photo, anchor="nw")

# Create a new frame for the buttons
button_frame = tk.Frame(root)
button_frame.pack()

# Create buttons
Red_button = tk.Button(button_frame, text="Red Block", command=lambda: change_block("Red"))
Red_button.pack(side=tk.LEFT)

Orange_button = tk.Button(button_frame, text="Orange Block", command=lambda: change_block("Orange"))
Orange_button.pack(side=tk.LEFT)

Yellow_button = tk.Button(button_frame, text="Yellow Block", command=lambda: change_block("Yellow"))
Yellow_button.pack(side=tk.LEFT)

Green_button = tk.Button(button_frame, text="Green Block", command=lambda: change_block("Green"))
Green_button.pack(side=tk.LEFT)

Blue_button = tk.Button(button_frame, text="Blue Block", command=lambda: change_block("Light Blue"))
Blue_button.pack(side=tk.LEFT)

Dark_Blue_button = tk.Button(button_frame, text="Dark Blue Block", command=lambda: change_block("Blue"))
Dark_Blue_button.pack(side=tk.LEFT)

Purple_button = tk.Button(button_frame, text="Purple Block", command=lambda: change_block("Purple"))
Purple_button.pack(side=tk.LEFT)

Pink_button = tk.Button(button_frame, text="Pink Block", command=lambda: change_block("Pink"))
Pink_button.pack(side=tk.LEFT)

White_button = tk.Button(button_frame, text="White Block", command=lambda: change_block("White"))
White_button.pack(side=tk.LEFT)

Black_button = tk.Button(button_frame, text="Black Block", command=lambda: change_block("Black"))
Black_button.pack(side=tk.LEFT)

Open_button = tk.Button(button_frame, text="Open", command=lambda: open_from_file())
Open_button.pack(side=tk.LEFT)

Save_button = tk.Button(button_frame, text="Save", command=lambda: save_to_file())
Save_button.pack(side=tk.LEFT)

Reset_button = tk.Button(button_frame, text="Clear Canvas", command=lambda: Clear_Canvas())
Reset_button.pack(side=tk.LEFT)

# Create a Text widget for displaying and editing text
text = Text(root, height=10, width=40)

# Start the block increment loop
add_blocks()

root.bind("<a>", move_rect)
root.bind("<d>", move_rect)
root.bind("<w>", move_rect)
root.bind("<s>", move_rect)
root.bind("<b>", move_rect)
root.bind("<m>", move_rect)
root.bind('<F11>', toggle_fullscreen)

root.mainloop()

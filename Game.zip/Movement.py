import tkinter as tk
from tkinter import Label
from PIL import Image, ImageTk

def move_rect(event):
    key = event.keysym
    if key == "a":
        canvas.move(sprite, -3, 0)
    elif key == "d":
        canvas.move(sprite, 3, 0)
    elif key == "w":
        canvas.move(sprite, 0, -3)
    elif key == "s":
        canvas.move(sprite, 0, 3)

root = tk.Tk()
root.title("Moving Sprite")
root.geometry("1550x950")
root.iconbitmap("Python.ico")
label = Label(text="Use WASD to move around, to change the player sprite, replace the Sprite.png with a small thing with a blank white background")
label.pack()


canvas = tk.Canvas(root, bg="white", height=999999, width=999999)
canvas.pack()

# Load your PNG image (replace 'Sprite.png' with the actual filename)
image = Image.open("Sprite.png")
photo = ImageTk.PhotoImage(image)

# Display the image on the canvas
sprite = canvas.create_image(0, 0, image=photo, anchor="nw")

# Bind the arrow keys to the move_rect function
root.bind("<a>", move_rect)
root.bind("<d>", move_rect)
root.bind("<w>", move_rect)
root.bind("<s>", move_rect)

root.mainloop()

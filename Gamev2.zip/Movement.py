import tkinter as tk
from tkinter import Label
from PIL import Image, ImageTk

# Constants
BLOCK_SIZE = 50
INITIAL_BLOCKS = 25
BLOCKS_INCREMENT = 25

def move_rect(event):
    global BLOCKS
    key = event.keysym
    if key == "a":
        move_player(-0.5, 0)
    elif key == "d":
        move_player(0.5, 0)
    elif key == "w":
        move_player(0, -0.5)
    elif key == "s":
        move_player(0, 0.5)
    elif key == "b":
        place_block()
    elif key == "m":
        mine_block()
    # Update the label text
    label.config(text=f"Use WASD to move around. Press 'b' to place a block and 'm' to mine. Blocks: {BLOCKS}")

def move_player(dx, dy):
    # Move the player by block size
    canvas.move(player_sprite, dx * BLOCK_SIZE, dy * BLOCK_SIZE)

def place_block():
    global BLOCKS
    if BLOCKS > 0:
        x, y = canvas.coords(player_sprite)
        canvas.create_rectangle(x, y, x + BLOCK_SIZE, y + BLOCK_SIZE, fill="green")
        BLOCKS -= 1

def mine_block():
    global BLOCKS
    x, y = canvas.coords(player_sprite)
    items = canvas.find_overlapping(x, y, x + BLOCK_SIZE, y + BLOCK_SIZE)
    for item in items:
        if item != player_sprite:
            canvas.delete(item)
            BLOCKS += 1

def add_blocks():
    global BLOCKS
    BLOCKS += BLOCKS_INCREMENT
    label.config(text=f"Use WASD to move around. Press 'b' to place a block and 'm' to mine. Blocks: {BLOCKS}")
    root.after(120000, add_blocks)  # Schedule the function to run again after 2 minutes (120,000 milliseconds)

# Initialize
BLOCKS = INITIAL_BLOCKS

root = tk.Tk()
root.title("Minecraft-Like Sprite")
root.geometry("1550x950")
root.iconbitmap("Python.ico")

label = Label(text=f"Use WASD to move around. Press 'b' to place a block and 'm' to mine. Blocks: {BLOCKS}")
label.pack()

canvas = tk.Canvas(root, bg="Sky blue", height=999999, width=999999)
canvas.pack()

# Load your PNG image (replace 'Sprite.png' with the actual filename)
image = Image.open("Sprite.png")
photo = ImageTk.PhotoImage(image)

# Display the image on the canvas
player_sprite = canvas.create_image(0, 0, image=photo, anchor="nw")

# Bind keys to functions
root.bind("<a>", move_rect)
root.bind("<d>", move_rect)
root.bind("<w>", move_rect)
root.bind("<s>", move_rect)
root.bind("<b>", move_rect)
root.bind("<m>", move_rect)

# Start the block increment loop
add_blocks()

root.mainloop()
